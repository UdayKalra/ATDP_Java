package CountryMap;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.*;
import javax.swing.JComponent;
import java.awt.geom.*;
class DrawMap extends JComponent implements MouseListener{
	public DrawMap(){
		this.addMouseListener(this);
		
	}

public void paint(Graphics g) {
    Graphics2D g2 = (Graphics2D) g;
   Image map = Toolkit.getDefaultToolkit().getImage("C:/Users/uday/workspace/CountryMap/bin/country.png");
    g2.drawImage(map, 0, 0, this);
    Line2D.Double can = new Line2D.Double(100,100,300,100);
    g2.setStroke(new BasicStroke(10));
   // g2.setColor(Color.BLUE);
   // g2.draw(can);
}

public void mousePressed(MouseEvent e) {
   
    System.out.println(e.getX());
    System.out.println(e.getY());
 }

 public void mouseReleased(MouseEvent e) {
    
 }

 public void mouseEntered(MouseEvent e) {
   
 }

 public void mouseExited(MouseEvent e) {
    
 }

 public void mouseClicked(MouseEvent e) {
   
 }

}
