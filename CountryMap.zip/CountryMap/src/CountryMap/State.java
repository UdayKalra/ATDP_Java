package CountryMap;

import java.awt.geom.Point2D;

public class State {
private String name;
private Point2D.Double point;
private String desc;
	public State(String nam){
		name = nam;
		
	}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Point2D.Double getPoint() {
	return point;
}
public void setPoint(Point2D.Double point) {
	this.point = point;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}


	
	
}
